function numInNum(num, sub) {
  return `${num}`.includes(`${sub}`)
}

console.log(numInNum(423423, 42))