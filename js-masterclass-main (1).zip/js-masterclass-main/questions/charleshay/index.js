const alignText = require("./alignText")

console.log(alignText("There once was a man from nantucket, who wanted to live in a bucket."))
