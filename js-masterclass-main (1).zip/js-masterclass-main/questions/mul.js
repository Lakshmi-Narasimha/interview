const mul = (val1) => (val2) => (val3) => val1 + val2 + val3

console.log(mul(2)(4)(6))